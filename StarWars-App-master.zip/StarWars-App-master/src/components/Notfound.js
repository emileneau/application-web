import React from 'react'

const Notfound = () => {
  return (
    <h2>
      Not Found 404:S
    </h2>
  )
}
export default Notfound;