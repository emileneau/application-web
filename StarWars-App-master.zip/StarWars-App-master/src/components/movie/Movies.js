import React from 'react';

const Movies = () => {
    return (
      <div>
        Movies Area
      </div>
    )
}

export default Movies;
