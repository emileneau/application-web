# Star Wars App
🌠 The Star Wars information project. I developed using ReactJs and Swapi.
![A screenshot of the Star Wars .](https://i.ibb.co/gv6HBrK/project-SS.png)